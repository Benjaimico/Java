package p;

public class Ppal {

	public static void main(String[] args) {
		Tablero tabla = new Tablero();
		Carro K = new Kromi(15,"15-12-06","2005","Mazda");
		Carro C = new Caguano(5,"12-02-03",25,"Verde paco");
		Carro T = new Trupalla(4,"23-04-07",4,"Elba Zurita");
		
		System.out.println(K.toString());
		System.out.println(C.toString());
		System.out.println(T.toString());
		
		Menu.menu();

	}

}
