
package p;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Tablero {
	// suma de puntos
	static int sumaPtos = 0;
	// Carros
	static int pos = 0; // posicion
	static int k = 3; // Kromi
	static int c = 5; // Caguano
	static int t = 10; // Trupalla

	private static Carro[] vehiculos = new Carro[18]; // lista de carros
	protected static ArrayList<Integer> totalPtos; // lista de puntos
	ArrayList<Huevo> disparos = new ArrayList<Huevo>(); // lista de huevos

	public Tablero() {
		// Puntaje
		totalPtos = new ArrayList<Integer>();
		Huevo.tablero = new char[15][15];
		for (int i = 0; i < Huevo.tablero.length; i++) {
			for (int j = 0; j < Huevo.tablero[i].length; j++) {
				Huevo.tablero[i][j] = ' ';
			}
		}
	}

	public static void generarCarros() {// declara cada uno de los carros
		//Kromi
		for (int i = 0; i < k; i++) {
			Carro kromi = new Kromi();
			vehiculos[pos] = kromi;
			posKromi();
			pos++;
		}
		//Caguano
		for (int i = 0; i < c; i++) {
			Carro caguano = new Caguano();
			vehiculos[pos] = caguano;
			posCaguano();
			pos++;
		}
		//Trupalla
		for (int i = 0; i < t; i++) {
			Carro trupalla = new Trupalla();
			vehiculos[pos] = trupalla;
			posTrupalla();
			pos++;
		}
	}

	public static void posKromi() { 		// genera la posicion de las Kromi
		int x = (int) (Math.random() * 13);
		int y = (int) (Math.random() * 15);

		if (Huevo.tablero[x][y] == ' ' && Huevo.tablero[x + 1][y] == ' ' && Huevo.tablero[x + 2][y] == ' ') {
			Huevo.tablero[x][y] = 'K';
			Huevo.tablero[x + 1][y] = 'K';
			Huevo.tablero[x + 2][y] = 'K';
		} else {
			while (true) {
				x = (int) (Math.random() * 13);
				y = (int) (Math.random() * 15);
				if (Huevo.tablero[x + 1][y] == ' ' && Huevo.tablero[x + 2][y] == ' ') {
					Huevo.tablero[x][y] = 'K';
					Huevo.tablero[x + 1][y] = 'K';
					Huevo.tablero[x + 2][y] = 'K';
					break;
				}
			}
		}
	}

	public static void posCaguano() {// genera la posicion de los Caguano
		int x = (int) (Math.random() * 15);
		int y = (int) (Math.random() * 14);

		if (Huevo.tablero[x][y] == ' ' && Huevo.tablero[x][y + 1] == ' ') {
			Huevo.tablero[x][y] = 'C';
			Huevo.tablero[x][y + 1] = 'C';
		} else {
			while (true) {
				x = (int) (Math.random() * 15);
				y = (int) (Math.random() * 14);
				if (Huevo.tablero[x][y] == ' ' && Huevo.tablero[x][y + 1] == ' ') {
					Huevo.tablero[x][y] = 'C';
					Huevo.tablero[x][y + 1] = 'C';
					break;
				}
			}
		}
	}

	public static void posTrupalla() { 	// genera la posicion de los Trupalla
		int x = (int) (Math.random() * 15);
		int y = (int) (Math.random() * 15);

		if (Huevo.tablero[x][y] == ' ') {
			Huevo.tablero[x][y] = 'T';

		} else {
			while (true) {
				x = (int) (Math.random() * 15);
				y = (int) (Math.random() * 15);
				if (Huevo.tablero[x][y] == ' ') {
					Huevo.tablero[x][y] = 'T';
					break;
				}
			}
		}
	}

	public static void mostrarMapa() { //Muestra el tablero
		System.out.print("  ");

		for (int i = 0; i < Huevo.tablero.length; i++) // dibuja los espacion en blanco del tablero
			if (i <= 9) {
				System.out.print(i + "  ");
			} else {
				System.out.print(i);
			}
		System.out.println();

		for (int i = 0; i < Huevo.tablero.length; i++) { //  dibuja las grillas del tablero
			for (int j = 0; j < Huevo.tablero[i].length; j++) {
				if (j == 0) {
					System.out.print(i + "| " + Huevo.tablero[i][j] + " |");
				} else if (j == Huevo.tablero[i].length - 1) {
					System.out.print(Huevo.tablero[i][j] + " |");
				} else {
					System.out.print(Huevo.tablero[i][j] + " |");
				}
			}
			System.out.println();
		}
	}

	public static void totalPtos() { // calcula la suma del puntaje
		for (int i = 0; i < totalPtos.size(); i++) {
			sumaPtos += totalPtos.get(i);
		}
		System.out.println("El puntaje total es: " + sumaPtos);
		System.out.println("Ha lanzado: " + (Huevo.huevosLanzados) + " huevos");
		System.out.println("Huevos por lanzar: " + (Huevo.huevosDisponibles));
	}

}