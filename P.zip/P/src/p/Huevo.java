package p;

import java.util.Scanner;

public class Huevo extends Tablero {
	protected static int huevosLanzados = 0; // suma los huevos lanzados
	protected static int huevosDisponibles = 225; // resta un huevo por lanzamiento
	protected static char[][] tablero;

	public static void lanzarHuevo() { // solicita coordenadas para lanzar el huevo
		System.out.println("\nRealiza un disparo");
		int x = -1, y = -1;
		do {
			Scanner input = new Scanner(System.in);
			System.out.print("Ingresa X (0-14): ");
			x = input.nextInt();
			if (x < 0 || x > 14) {// coordenadas invalidas
				System.out.println("Ingresa una coordenada valida");
			} else {
				System.out.print("Ingresa Y (0-14): ");
				y = input.nextInt();
				if (y < 0 || y > 14) {
					System.out.println("Ingresa una coordenada valida");
				}
			}

			if ((x >= 0 && x < 15) && (y >= 0 && y < 15)) { // huevo en coordenada de Trupalla
				if (tablero[x][y] == 'T') {
					tablero[x][y] = 'H';
					huevosLanzados++;
					huevosDisponibles--;
					totalPtos.add(1);
					Tablero.mostrarMapa();
					System.out.println("Le has dado a un Trupalla");
					System.out.println("Recibes 1 pto");

				} else if (tablero[x][y] == 'C') { // huevo en coordenada de Caguano
					tablero[x][y] = 'H';
					huevosLanzados++;
					huevosDisponibles--;
					totalPtos.add(2);
					if ((y == 0) && (tablero[x][y] == 'H' && tablero[x][y + 1] == 'H')) { // puntos extra por desruir un Caguano
						Tablero.mostrarMapa();
						System.out.println("Destruiste un Caguano");
						totalPtos.add(7);
						System.out.println("Recibes 7 ptos");
					} else if ((y == 14) && (tablero[x][y] == 'H' && tablero[x][y - 1] == 'H')) {
						Tablero.mostrarMapa();
						System.out.println("Destruiste un Caguano");
						totalPtos.add(7);
						System.out.println("Recibes 7 ptos");
					} else if ((y >= 1 || y <= 13) && (tablero[x][y] == 'H' && tablero[x][y + 1] == 'H')
							|| (tablero[x][y] == 'H' && tablero[x][y - 1] == 'H')) {
						Tablero.mostrarMapa();
						System.out.println("Destruiste un Caguano");
						totalPtos.add(7);
						System.out.println("Recibes 7 ptos");

					} else {
						Tablero.mostrarMapa();
						System.out.println("Le has dado a un Caguano");
						System.out.println("Recibes 2 ptos");
					}

				} else if (tablero[x][y] == 'K') { // huevo en coordenada de Kromi
					tablero[x][y] = 'H';
					huevosLanzados++;
					huevosDisponibles--;
					totalPtos.add(3);
					if ((x == 0) && (tablero[x][y] == 'H' && tablero[x + 1][y] == 'H' && tablero[x + 2][y] == 'H')) {
						totalPtos.add(10);
						Tablero.mostrarMapa();
						System.out.println("Destruiste una Kromi");
						System.out.println("Recibes 10 ptos");
					} else if ((x == 14)
							&& (tablero[x][y] == 'H' && tablero[x - 1][y] == 'H' && tablero[x - 2][y] == 'H')) {
						totalPtos.add(10);
						Tablero.mostrarMapa();
						System.out.println("Destruiste una Kromi");
						System.out.println("Recibes 10 ptos");
					} else if ((x >= 2 && x <= 12) && ((tablero[x][y] == 'H' && tablero[x + 1][y] == 'H'
							&& tablero[x + 2][y] == 'H')
							|| (tablero[x][y] == 'H' && tablero[x - 1][y] == 'H' && tablero[x - 2][y] == 'H'))) {
						totalPtos.add(10);
						Tablero.mostrarMapa();
						System.out.println("Destruiste una Kromi");
						System.out.println("Recibes 10 ptos");
						if ((x >= 1 || x <= 13)
								&& (tablero[x][y] == 'H' && tablero[x + 1][y] == 'H' && tablero[x - 1][y] == 'H')) {
							totalPtos.add(10);
							Tablero.mostrarMapa();
							System.out.println("Destruiste una Kromi");
							System.out.println("Recibes 10 ptos");
						}
					} else {
						Tablero.mostrarMapa();
						System.out.println("Le has dado a una Kromi");
					}
				}else if (tablero[x][y] == 'H') { // huevo en coordenada ya indicada
						Tablero.mostrarMapa(); 
						System.out.println("Ya habias lanzado en este punto");
					
				} else if (tablero[x][y] == ' ') { // huevo en coordenada vacia
					huevosLanzados++;
					huevosDisponibles--;
					tablero[x][y] = 'H';
					Tablero.mostrarMapa();
					System.out.println("Fallaste");
				} else if ((x < 0 || x >= 15) || (y < 0 || y >= 15)) // intento invalido
					System.out.println("Debes ingresar una coordenada valida");

				} else if ((huevosDisponibles == 0) || (Tablero.sumaPtos == 122)) {			
					System.out.println("HAS DESTRUIDO TODOS LOS CARROS");
					System.out.println("--------FIN DEL JUEGO--------");
			}
		} while (Tablero.sumaPtos != 0);
		System.out.println("");
	}
}
