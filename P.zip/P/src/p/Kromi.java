package p;

public class Kromi extends Carro {

	String fabricacion;
	String marca;

	public Kromi() {
		super();
	}

	public Kromi(int cantOcupantes, String fechaIngreso, String fabricacion, String marca) {
		super(cantOcupantes, fechaIngreso);
		this.fabricacion = fabricacion;
		this.marca = marca;
	}

	public String getFabricacion() {
		return fabricacion;
	}

	public void setFabricacion(String fabricacion) {
		this.fabricacion = fabricacion;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "Kromi" + "\nOcupantes: " + cantOcupantes + "\nFecha de ingreso: " + fechaIngreso
				+ "\nAño de fabricacion: " + fabricacion + "\nMarca: " + marca;
	}

}
