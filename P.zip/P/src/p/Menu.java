package p;

import java.util.Scanner;

public class Menu {
	public static void menu() {
		Scanner input = new Scanner(System.in);
		int opciones;

		do {
			System.out.println("MENU");
			System.out.println("1. Crear tablero");
			System.out.println("2. Lanzar huevo");
			System.out.println("3. Mostrar tablero");
			System.out.println("4. Calcular puntaje");
			System.out.println("5. Salir");
			System.out.print("Elige una opción: ");

			opciones = input.nextInt();
			switch (opciones) {
			case 1:
				System.out.println("Creando tablero...");
				Tablero.generarCarros();
				break;
			case 2:
				System.out.println("Lanzar Huevo");
				Huevo.lanzarHuevo();
				break;
			case 3:
				System.out.println("Mostrar Tablero");
				Tablero.mostrarMapa();
				break;
			case 4:
				System.out.println("Calcular Puntaje");
				Tablero.totalPtos();
				break;
			case 5:
				System.out.println("Fin del juego");
				Tablero.totalPtos();
				break;
			default:
				System.out.println("Reintente");
				break;
			}
		} while (opciones != 5);

	}
}
