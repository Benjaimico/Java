package p;

public class Trupalla extends Carro {

	int armadura;
	String conductor;

	public Trupalla() {
		super();
	}

	public Trupalla(int cantOcupantes, String fechaIngreso, int armadura, String conductor) {
		super(cantOcupantes, fechaIngreso);
		this.armadura = armadura;
		this.conductor = conductor;

	}

	public int getArmadura() {
		return armadura;
	}

	public void setArmadura(int armadura) {
		this.armadura = armadura;
	}

	public String getConductor() {
		return conductor;
	}

	public void setConductor(String conductor) {
		this.conductor = conductor;
	}

	@Override
	public String toString() {
		return "Trupalla" + "\nOcupantes: " + cantOcupantes + "\nFecha de ingreso: " + fechaIngreso + "\nArmadura: "
				+ armadura + "\nConductor: " + conductor;
	}
}
