package p;

public class Caguano extends Carro{

	int alcanceTiro;
	String colorConfeti;
	
	public Caguano() {
		super();
	}
	public Caguano(int cantOcupantes, String fechaIngreso, int alcanceTiro, String colorConfeti) {
		super(cantOcupantes, fechaIngreso);
		this.alcanceTiro = alcanceTiro;
		this.colorConfeti = colorConfeti;
	}

	public int getAlcanceTiro() {
		return alcanceTiro;
	}

	public void setAlcanceTiro(int alcanceTiro) {
		this.alcanceTiro = alcanceTiro;
	}

	public String getColorConfeti() {
		return colorConfeti;
	}

	public void setColorConfeti(String colorConfeti) {
		this.colorConfeti = colorConfeti;
	}

	@Override
	public String toString() {
		return "Caguano" + "\nOcupantes: " + cantOcupantes + "\nFecha de ingreso: " + fechaIngreso + "\nAlcance de tiro: "
	+ alcanceTiro +" metros" + "\nColor de confeti: " + colorConfeti;
	}
	
	
}
