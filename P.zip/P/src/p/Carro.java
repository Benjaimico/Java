package p;

public class Carro {
	
	int cantOcupantes;
	String fechaIngreso;
	
	public Carro() {
		
		
	}
	
	public Carro(int cantOcupantes, String fechaIngreso) {
		this.cantOcupantes = cantOcupantes;
		this.fechaIngreso = fechaIngreso;
	}

	public int getCantOcupantes() {
		return cantOcupantes;
	}

	public void setCantOcupantes(int cantOcupantes) {
		this.cantOcupantes = cantOcupantes;
	}

	public String getFechaIngreso() {
		return fechaIngreso;
	}

	public void setFechaIngreso(String fechaIngreso) {
		this.fechaIngreso = fechaIngreso;
	}
	@Override
	public String toString() {
		return "Ocupantes: " + cantOcupantes + "Fecha de ingreso: " + fechaIngreso;
	}
	
}

